import json
import discord
import os

from discord.ext import commands, tasks
from discord.ext.commands import Cog 
from datetime import datetime

class TasksLoops(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @tasks.loop(minutes=10)
    async def save_chat(self, ctx, message):

        with open('./modules/discord_server/json_files/employees.json', 'r', encoding='utf-8-sig') as f:
            data = json.load(f)

        limit = 5000

        data["messages"][str(ctx.message.channel.id())] = {f'{ctx.message.content()}'}