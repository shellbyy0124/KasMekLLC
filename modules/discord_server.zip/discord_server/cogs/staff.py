import discord

from discord.ext import commands
from discord.ext.commands import Cog 

class StaffStuff(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @commands.command()
    @commands.has_role('Staff')
    async def something(self, ctx):

        pass

def setup(bot):
    bot.add_cog(StaffStuff(bot))