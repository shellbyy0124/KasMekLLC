from Modules.CEO.ceo import ChiefExecOfficer

{
    "BD": board_of_directors,
    "CEO": ChiefExecOfficer,
    "CTO": chief_tech_off,
    "CIO": chief_inn_off,
    "VPE": vice_pres_eng,
    "VPM": vice_pres_mark,
    "VPPM": vice_pres_proj_mang,
    "EPM": eng_proj_mang,
    "CA": chief_arch,
    "SSA": senior_soft_arch,
    "SA": soft_arch,
    "PSE": princ_soft_eng,
    "SSE": sen_soft_eng,
    "TL": team_lead,
    "SD": soft_dev,
    "JSD": junior_soft_dev,
    "ISD": intern_soft_dev,
}