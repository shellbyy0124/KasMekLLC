      __Highlights__

- 👋 Hi, I’m Shellbyy!
- 👀 I’m interested in python programming conclusive with software development, and discord.py
- 🌱 I’m currently learning PyQt5, discord.py, json, sqlite3
- 💞️ I’m currently not looking to collaborate on my projects that are connected to my repo as they are just hobbies
- 📫 You can reach me on discord. Shellbyy#8025

      __Main__
Hi, I'm Shellbyy. I have been programming for over a year now, and although I am taking my studies slow, that will soon change. I have enrolled in college to be able to obtain my Ph.D. in Computer Science. I am choosing to focus in Software Developement, with a highlight of Cyber Security. If I'm going to build my own software, it needs to be protected right, HAHA! Anyways, I'm a 29 year old female programmer. I spend most of my time working on my hobbies, and getting prepared for school. I try to make my projects creative. I.E. whatever comes to my mind I'll start on. Programming in general has become a very fun thing for me and I'm excited about what all I have left to learn!

I will have files names "comments.txt" in each file throughout the project. They're notes for me of things to go back, and continue later after I have learned how to do them. I will update to the repo as I successfully achieve each functions phase. 

I do my projects versions by 0.0.2 i.e. 0.0.2, 0.0.4, 0.0.6, 0.0.8, 0.2.0, and so on