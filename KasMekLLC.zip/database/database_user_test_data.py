# (user-id, name, password, job_title)

data = [
    ('1', 'Shellby', 'whynot123', 'CEO'),
    ('2', 'Chris', 'password', 'CTO'),
    ('GamingBuddhist', 'another Chris', 'MyPasswordIsStrong', 'SD'),
    ('test_user4', 'Bob', 'iambob', 'Jester'),
    ('test5', 'Jonny', '1234', 'Coffee Squire'),
]